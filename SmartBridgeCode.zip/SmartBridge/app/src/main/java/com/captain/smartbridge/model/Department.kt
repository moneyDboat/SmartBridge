package com.captain.smartbridge.model

/**
 * Created by Captain on 17/6/27.
 */


/**
 * departEngName : SEU
 * departName : 东南大学
 * departNo : 1
 */

data class Department (
    var departEngName: String? = null,
    var departName: String? = null,
    var departNo: Int = 0
)
