package com.captain.smartbridge.model;

/**
 * Created by fish on 17-6-6.
 */

public class SearchCodeRes {
    /**
     * qlgljsdj : 201
     * qldm : G00010008
     * fs : 3
     * zxzh : 22222
     * jqsj : 2017-02-01
     * wd : 31.216677
     * qx : 弋江区
     * sjsj : 2015-02-08
     * skdwlx : 401
     * qllx : 301
     * jqwz :
     * jd : 118.335970
     * qlqc : 7.52
     * lxlx : 001
     * bz :
     * qlmc : 望东大桥
     * cs : 芜湖市
     * qlfl : 101
     * sf : 安徽省
     * gldw : 0
     * lxh : L00010008
     */

    private String qlgljsdj;
    private String qldm;
    private String fs;
    private String zxzh;
    private String jqsj;
    private String wd;
    private String qx;
    private String sjsj;
    private String skdwlx;
    private String qllx;
    private String jqwz;
    private String jd;
    private String qlqc;
    private String lxlx;
    private String bz;
    private String qlmc;
    private String cs;
    private String qlfl;
    private String sf;
    private String gldw;
    private String lxh;

    public String getQlgljsdj() {
        return qlgljsdj;
    }

    public void setQlgljsdj(String qlgljsdj) {
        this.qlgljsdj = qlgljsdj;
    }

    public String getQldm() {
        return qldm;
    }

    public void setQldm(String qldm) {
        this.qldm = qldm;
    }

    public String getFs() {
        return fs;
    }

    public void setFs(String fs) {
        this.fs = fs;
    }

    public String getZxzh() {
        return zxzh;
    }

    public void setZxzh(String zxzh) {
        this.zxzh = zxzh;
    }

    public String getJqsj() {
        return jqsj;
    }

    public void setJqsj(String jqsj) {
        this.jqsj = jqsj;
    }

    public String getWd() {
        return wd;
    }

    public void setWd(String wd) {
        this.wd = wd;
    }

    public String getQx() {
        return qx;
    }

    public void setQx(String qx) {
        this.qx = qx;
    }

    public String getSjsj() {
        return sjsj;
    }

    public void setSjsj(String sjsj) {
        this.sjsj = sjsj;
    }

    public String getSkdwlx() {
        return skdwlx;
    }

    public void setSkdwlx(String skdwlx) {
        this.skdwlx = skdwlx;
    }

    public String getQllx() {
        return qllx;
    }

    public void setQllx(String qllx) {
        this.qllx = qllx;
    }

    public String getJqwz() {
        return jqwz;
    }

    public void setJqwz(String jqwz) {
        this.jqwz = jqwz;
    }

    public String getJd() {
        return jd;
    }

    public void setJd(String jd) {
        this.jd = jd;
    }

    public String getQlqc() {
        return qlqc;
    }

    public void setQlqc(String qlqc) {
        this.qlqc = qlqc;
    }

    public String getLxlx() {
        return lxlx;
    }

    public void setLxlx(String lxlx) {
        this.lxlx = lxlx;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

    public String getQlmc() {
        return qlmc;
    }

    public void setQlmc(String qlmc) {
        this.qlmc = qlmc;
    }

    public String getCs() {
        return cs;
    }

    public void setCs(String cs) {
        this.cs = cs;
    }

    public String getQlfl() {
        return qlfl;
    }

    public void setQlfl(String qlfl) {
        this.qlfl = qlfl;
    }

    public String getSf() {
        return sf;
    }

    public void setSf(String sf) {
        this.sf = sf;
    }

    public String getGldw() {
        return gldw;
    }

    public void setGldw(String gldw) {
        this.gldw = gldw;
    }

    public String getLxh() {
        return lxh;
    }

    public void setLxh(String lxh) {
        this.lxh = lxh;
    }
}
