package com.captain.smartbridge.model

/**
 * Created by Captain on 17/6/27.
 */

/**
 * rwfbry : fansen
 * rwfbsj : 2017-06-12 14:13:11
 * qldm : G00010002
 * jcrw_id : 36760c42-4f36-11e7-af2f-784f4386462e
 */

data class CreateMissRes (
    var rwfbry: String? = null,
    var rwfbsj: String? = null,
    var qldm: String? = null,
    var jcrw_id: String? = null
)
