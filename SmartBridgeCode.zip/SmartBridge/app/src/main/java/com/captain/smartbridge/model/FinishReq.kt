package com.captain.smartbridge.model

/**
 * Created by Captain on 17/7/2.
 */

data class FinishReq (
    /**
     * jcrw_id : 201706011128390
     */

    var jcrw_id: String? = null
)
