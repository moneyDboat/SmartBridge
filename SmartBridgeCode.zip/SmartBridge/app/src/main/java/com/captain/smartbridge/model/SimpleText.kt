package com.captain.smartbridge.model

/**
 * Created by fish on 17-5-15.
 */

class SimpleText(var title: String?, var context: String?)
