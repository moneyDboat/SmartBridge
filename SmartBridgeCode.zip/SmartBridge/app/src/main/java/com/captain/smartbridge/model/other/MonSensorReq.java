package com.captain.smartbridge.model.other;

/**
 * Created by Captain on 17/8/21.
 */

public class MonSensorReq {

    /**
     * id : 35
     */

    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
