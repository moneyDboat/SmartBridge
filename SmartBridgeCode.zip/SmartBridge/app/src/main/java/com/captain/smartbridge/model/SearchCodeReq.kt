package com.captain.smartbridge.model

/**
 * Created by fish on 17-6-6.
 */

/**
 * qldm : G00010010
 */

data class SearchCodeReq(var qldm: String)