package com.captain.smartbridge.Common;

/**
 * Created by fish on 17-6-2.
 */

public class Tools {
//    //使用Glide加载网络图片
//    public static void showImageWithGlide(Context context, final CircleImageView imageView, String url){
//        Glide.with(context)
//                .load(url)
//                .placeholder(R.drawable.login_pho)
//                .into(new SimpleTarget<GlideDrawable>() {
//                    @Override
//                    public void onResourceReady(GlideDrawable resource, GlideAnimation<? super GlideDrawable> glideAnimation) {
//                        imageView.setImageDrawable(resource);
//                    }
//                });
//    }
//    //使用Glide加载网络图片
//    public static void showImageWithGlide(Context context, final ImageView imageView, String url){
//        Glide.with(context)
//                .load(url)
//                .placeholder(R.drawable.login_pho)
//                .into(new SimpleTarget<GlideDrawable>() {
//                    @Override
//                    public void onResourceReady(GlideDrawable resource, GlideAnimation<? super GlideDrawable> glideAnimation) {
//                        imageView.setImageDrawable(resource);
//                    }
//                });
//    }
}
