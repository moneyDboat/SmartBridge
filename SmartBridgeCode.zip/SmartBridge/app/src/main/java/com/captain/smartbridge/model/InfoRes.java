package com.captain.smartbridge.model;

/**
 * Created by fish on 17-6-5.
 */

public class InfoRes {

    /**
     * username : fansen
     * roleType : 1
     * registerDate : 2017-01-13
     * headPortrait : 3e144759-1fe2-45e4-b49c-6beb81cf18c6.jpg
     * sf : null
     * userId : 4
     * inspectionDepartmentDM : NJ2013
     * phoneNumber : 18252081639
     * cs : null
     * lastLoginTime : 2017-06-06 17:46:04
     * password : 123456
     * nickname : fans
     * email : 1803780069@qq.com
     */

    private String username;
    private int roleType;
    private String registerDate;
    private String headPortrait;
    private String sf;
    private int userId;
    private String inspectionDepartmentDM;
    private String phoneNumber;
    private String cs;
    private String lastLoginTime;
    private String password;
    private String nickname;
    private String email;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getRoleType() {
        return roleType;
    }

    public void setRoleType(int roleType) {
        this.roleType = roleType;
    }

    public String getRegisterDate() {
        return registerDate;
    }

    public void setRegisterDate(String registerDate) {
        this.registerDate = registerDate;
    }

    public String getHeadPortrait() {
        return headPortrait;
    }

    public void setHeadPortrait(String headPortrait) {
        this.headPortrait = headPortrait;
    }

    public String getSf() {
        return sf;
    }

    public void setSf(String sf) {
        this.sf = sf;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getInspectionDepartmentDM() {
        return inspectionDepartmentDM;
    }

    public void setInspectionDepartmentDM(String inspectionDepartmentDM) {
        this.inspectionDepartmentDM = inspectionDepartmentDM;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getCs() {
        return cs;
    }

    public void setCs(String cs) {
        this.cs = cs;
    }

    public String getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(String lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
