package com.captain.smartbridge.model

/**
 * Created by Captain on 17/6/5.
 */

/**
 * sf : 江苏省
 * cs : 南京市
 */

data class MapReq(var sf: String,var cs: String)
