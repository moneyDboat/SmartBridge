package com.captain.smartbridge.model

/**
 * Created by fish on 17-5-16.
 */

data class BridgeList(var name: String?, var code: String?, var location: String?)
