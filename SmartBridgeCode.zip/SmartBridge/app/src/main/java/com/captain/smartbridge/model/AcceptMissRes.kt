package com.captain.smartbridge.model

/**
 * Created by Captain on 17/6/27.
 */

/**
 * status : 1
 * rwjsry : lei123
 * rwjssj : 2017-06-12
 * jcrw_id : af53cee6-4f32-11e7-93f6-784f4386462e
 */

data class AcceptMissRes(
        var status: String? = null,
        var rwjsry: String? = null,
        var rwjssj: String? = null,
        var jcrw_id: String? = null
)
