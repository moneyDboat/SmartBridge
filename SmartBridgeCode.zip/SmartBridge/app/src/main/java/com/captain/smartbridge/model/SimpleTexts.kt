package com.captain.smartbridge.model

/**
 * Created by fish on 17-5-15.
 */

class SimpleTexts(var name: String?, var kind: String?, var num: String?, var category: String?)
