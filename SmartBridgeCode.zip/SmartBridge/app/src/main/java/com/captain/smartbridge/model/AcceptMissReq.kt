package com.captain.smartbridge.model

/**
 * Created by Captain on 17/6/27.
 */

/**
 * jcrw_id : af53cee6-4f32-11e7-93f6-784f4386462e
 */

data class AcceptMissReq (
    var jcrw_id: String? = null
)
