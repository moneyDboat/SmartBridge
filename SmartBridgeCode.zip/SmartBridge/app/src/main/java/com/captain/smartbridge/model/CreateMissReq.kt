package com.captain.smartbridge.model

/**
 * Created by Captain on 17/6/27.
 */

/**
 * qldm : G00010002
 * qljcdwdm : 2
 */

data class CreateMissReq (
    var qldm: String? = null,
    var qljcdwdm: String? = null
)
