package com.captain.smartbridge.model

// import com.amap.api.maps2d.model.LatLng

/**
 * Created by fish on 17-5-15.
 */

class Bridge {
//    var latLng: LatLng? = null
//    var name: String? = null
//    var location: String? = null
//    var code: String? = null
//    var level: String? = null
}
