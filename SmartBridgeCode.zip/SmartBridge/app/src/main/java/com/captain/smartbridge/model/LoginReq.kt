package com.captain.smartbridge.model

/**
 * Created by fish on 17-6-2.
 */
data class LoginReq(var username: String, var password: String)