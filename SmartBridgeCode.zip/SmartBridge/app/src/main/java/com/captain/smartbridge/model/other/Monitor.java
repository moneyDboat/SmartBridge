package com.captain.smartbridge.model.other;

/**
 * Created by Captain on 17/8/21.
 */

public class Monitor {
}
