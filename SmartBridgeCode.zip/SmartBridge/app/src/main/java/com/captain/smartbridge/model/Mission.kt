package com.captain.smartbridge.model

/**
 * Created by fish on 17-5-17.
 */

class Mission(
        var name: String,
        var code: String,
        var asign: String,
        var detect: String,
        var status: Int)
