package com.captain.smartbridge.model;

/**
 * Created by fish on 17-6-6.
 */

public class BridgeReq {

}
