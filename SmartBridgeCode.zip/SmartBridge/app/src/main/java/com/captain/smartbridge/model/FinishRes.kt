package com.captain.smartbridge.model

/**
 * Created by Captain on 17/7/2.
 */

class FinishRes {
    /**
     * status : 2
     * rwjsry : world
     * rwwcsj : 2017-07-01
     * jcrw_id : 201706011128390
     */

    var status: String? = null
    var rwjsry: String? = null
    var rwwcsj: String? = null
    var jcrw_id: String? = null
}
